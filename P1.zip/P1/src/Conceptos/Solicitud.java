/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conceptos;

import java.time.LocalDateTime;
import java.util.ArrayList;


/**
 *
 * @author evans
 */
public class Solicitud {
    private int id;
    private LocalDateTime fecha;
    private Servicio  servicio;
    private Cliente cliente;
    private Abogado abogado;
    private Estado estado;
    private String observaciones; 
    public ArrayList<Integer> otrosServicios = new ArrayList();

    public Solicitud(int id, LocalDateTime fecha, Servicio servicio, Cliente cliente, Abogado abogado, Estado estado, String observaciones) {
        this.id = id;
        this.fecha = fecha;
        this.servicio = servicio;
        this.cliente = cliente;
        this.abogado = abogado;
        this.estado = estado;
        this.observaciones = observaciones;
    }

    public Solicitud() {
        this.id = 1;
        this.observaciones = "";
    }

    public int getId() {
        return id;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public Servicio getServicio() {
        return servicio;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Abogado getAbogado() {
        return abogado;
    }

    public Estado getEstado() {
        return estado;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public ArrayList<Integer> getOtrosServicios() {
        return otrosServicios;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setAbogado(Abogado abogado) {
        this.abogado = abogado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setOtrosServicios(ArrayList<Integer> otrosServicios) {
        this.otrosServicios = otrosServicios;
    }
    
}
