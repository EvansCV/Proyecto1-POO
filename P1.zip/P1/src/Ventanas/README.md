# Proyecto1-POO
Repo del primer proyecto de POO, con fines de colaborar y tener mejor organización
