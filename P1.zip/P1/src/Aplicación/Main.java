/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Aplicación;

import Conceptos.Abogado;
import java.util.ArrayList;
import Conceptos.Servicio;
import Conceptos.Cliente;
import Conceptos.Estado;
import Conceptos.Solicitud;
import Ventanas.Menu;

/** Proyecto 1, POO
 * @author 
 * Evans Corrales Valverde carne 2024182013
 * Dario Soto Badilla carne 2024109692
 * Fecha de entrega: 8 de mayo, 2025
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
    public static ArrayList<Cliente> clientes = Util.HandlerClientes.cargar("Data\\clientes.xml");
    public static ArrayList<Abogado> abogados = Util.HandlerAbogados.cargar("Data\\abogados.xml");
    public static ArrayList<Servicio> servicios = Util.HandlerServicios.cargar("Data\\servicios.xml");
    public static ArrayList<Estado> estados = Util.HandlerEstados.cargar("Data\\estados.xml");
    public static ArrayList<Estado> solicitudes = Util.HandlerEstados.cargar("Data\\solicitudes.xml");
    
    public static void main(String[] args) {
        Menu m1 = new Menu();
        m1.setVisible(true);    
    }   
}
